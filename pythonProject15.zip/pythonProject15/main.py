from flask import Flask, redirect, url_for, render_template, request, session,flash
import csv
from bs4 import BeautifulSoup
# import os
# os.system("pip install flask-sqlalchemy")
import requests

from flask_sqlalchemy import SQLAlchemy
app=Flask(__name__)
app.config['SECRET_KEY'] = 'quiz'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///The_movies.sqlite'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Movies(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(50), nullable=False)
    password = db.Column(db.String(50), nullable=False)
    country = db.Column(db.String(50), nullable=False)


db.create_all()






# url = 'https://srulad.com/movies'


url = f'https://srulad.com/movies/page/1'
r = requests.get(url)
print(r)
soup = BeautifulSoup(r.text, 'html.parser')
# print(soup)
movies = soup.find('div', class_='row')
# print(movies)
all_movies = movies.find_all('div', class_='col-md-4 col-lg-3')
# print(all_movies)


# my_imdb = ''
# for each in all_movies:
#     link=each.a.attrs['href']
#     # print(link)
#     name = each.h2.text
#     imdb = each.find('span', class_ = 'imdb_rating').text
#     print(imdb)
#     my_imdb=imdb
    # print(name)






@app.route('/index.html')
@app.route('/')
def home():
    return render_template('index.html')

# @app.route('/movies.html')
# def movie(my_imdb):
#     return render_template('movie.html', my_imdb=imdb )
#     # return url_for('movie', imdb=imdb)

# @app.route('/login', methods=['POST', 'GET'])
# def login():
#     if requests.method=='POST':
#         username = requests.form['username']
#         return redirect((url_for('movie')))

@app.route('/movies.html')
def movie():
    imdbs = []
    links = []
    links2 = []
    names = []
    for each in all_movies:
        url = each.find('img', class_='card-img-top lazyLoad embed-responsive-item')
        link = url.get('data-src')
        links.append(link)
            # print(link)
        name = each.h2.text
        names.append(name)
        imdb = each.find('span', class_='imdb_rating').text
        link2 = each.a.attrs['href']
        links2.append(link2)
        print(link2)
        # print(imdb)
        imdbs.append(imdb)
    print(imdbs)
    return render_template('movie.html', len=len(imdbs),links = links, links2=links2, names =names, imdbs =imdbs,)


@app.route('/login.html', methods=['POST', 'GET'],)
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        country = request.form['country']
        new_movie = Movies(username=username, password=password, country=country)
        db.session.add(new_movie)
        db.session.commit()
        session['my_user'] = username
        flash(session['my_user'])
        return redirect(url_for('movie'))
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('my_user', None)
    return render_template('index.html')




if __name__ =='__main__':
    app.run(debug=True)







# url = 'https://srulad.com/movies'
# r = requests.get(url)
# print(r)
# soup = BeautifulSoup(r.text, 'html.parser')
# # print(soup)
# movies = soup.find('div', class_='row')
# # print(movies)
# all_movies = movies.find_all('div', class_='col-md-4 col-lg-3')
# # print(all_movies)
#
#
# my_imdb = ''
# for each in all_movies:
#     link=each.a.attrs['href']
#     # print(link)
#     name = each.h2.text
#     imdb = each.find('span', class_ = 'imdb_rating').text
#     print(imdb)
#     my_imdb=imdb
#     # print(name)


# @app.route('/movies.html')
# def movie():
#     imdbs = []
#     links = []
#     names = []
#     for each in all_movies:
#         url = each.find('img', class_='card-img-top lazyLoad embed-responsive-item')
#         link = url.get('data-src')
#         links.append(link)
#         # print(link)
#         name = each.h2.text
#         names.append(name)
#         imdb = each.find('span', class_='imdb_rating').text
#         # print(imdb)
#         imdbs.append(imdb)
#     print(imdbs)
#     return render_template('movie.html', len=len(imdbs),links = links, names =names, imdbs =imdbs)
#
